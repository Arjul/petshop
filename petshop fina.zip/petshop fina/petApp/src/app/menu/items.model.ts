export class ItemsModel{
    constructor(
        
        public itemName:String, 
        public itemCode:String,
        public available:String,
        public price:Number,
        public starRating:Number,
        
    ){}
}