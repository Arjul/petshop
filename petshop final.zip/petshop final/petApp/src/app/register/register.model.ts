export class registermodel{
    constructor(
        public name:String,
        public mobile:String,
        public email:String,
        public password:String,
        public type:String,
        public _id:String
    ){}
}